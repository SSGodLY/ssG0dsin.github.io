% CHAPTER_04
%
% Files
%   catReducer - Use mapreduce with an ImageDatastore


