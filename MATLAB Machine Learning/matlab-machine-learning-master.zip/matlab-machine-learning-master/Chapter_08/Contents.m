% CHAPTER_08
%
% Files
%   ClassifierSets          - Puts data into sets
%   DecisionTree            - Implements a decision tree
%   DrawBinaryTree          - Draw a binary tree in a new figure
%   HomogeneityMeasure      - The measure is 0 if the data is homogeneous
%   SimpleClassifierDemo    - Test the four class case with a manually created tree.
%   SimpleClassifierExample - Simple example with four classes
%   TestDecisionTree        - Test a decision tree.


