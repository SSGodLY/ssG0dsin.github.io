# Apress Source Code

This repository accompanies [*MATLAB Machine Learning*](http://www.apress.com/9781484222492) by Michael Paluszek and Stephanie Thomas (Apress, 2016).

![Cover image](9781484222492.jpg)

Download the files as a zip using the green button, or clone the repository to your machine using Git.

## Releases

Release v1.0 corresponds to the code in the published book, without corrections or updates.

## Contributions

See the file Contributing.md for more information on how you can contribute to this repository.
