% CHAPTER_09
%
% Files
%   CreateDigitImage  - Create an image of a single digit.
%   DigitTrainingData - Generate the training data
%   GetEntry          - Get an entry from a vector of graphics handles
%   IsValidField      - Determine if a field exists and is not empty.



